// Header file for all different
// types of pieces used
// in the Chess game

#ifndef PIECE_H
#define PIECE_H

class Piece
{
  public:
   void setName(char text) { name = text; };
   char getName() { return name; };
   void setID(char text) { id = text; };
   char getID() { return id; };
  private:
   char name;
   char id;
};

class Space : public Piece
{
  public:
   Space() { setName(' '); setID(' '); };
};

class Pawn : public Piece
{
  public:
   Pawn() { setName('p'); };
};

class Knight : public Piece
{
  public:
   Knight() { setName('N'); };
};

class Bishop : public Piece
{
  public:
   Bishop() { setName('B'); };
};

class Rook : public Piece
{
  public:
   Rook() { setName('R'); };
};

class Queen : public Piece
{
  public:
   Queen() { setName('Q'); };
};

class King : public Piece
{
  public:
   King() { setName('K'); };
};

#endif // PIECE_H
