// contains all function definitions
// for Board class

#include <iostream>
#include "board.h"
using namespace std;

/***********************************
 * BOARD: DEFUALT CONSTRUCTOR
 ***********************************/
Board::Board()
{
   player = "(White)"; // first player
   test = false;
   done = false;
   
   // set up all id chars for pieces
   k1.setID('K');
   k2.setID('k');
   q1.setID('Q');
   q2.setID('q');
   r1.setID('R');
   r2.setID('r');
   n1.setID('N');
   n2.setID('n');
   b1.setID('B');
   b2.setID('b');
   p1.setID('P');
   p2.setID('p');

   // set square colors for board
   for(int r = 0; r < 8; r++) 
      for (int c = 0; c < 8; c++)
      {
         if (r % 2 == 0)
            if (c % 2 == 0)
               isWhiteSquare[r][c] = true;
            else
               isWhiteSquare[r][c] = false;
         else
            if (c % 2 == 0)
               isWhiteSquare[r][c] = false;
            else
               isWhiteSquare[r][c] = true;
         if (r == 0) // set black pieces
         {
            if ((c == 0) || (c == 7))
               pieces[r][c] = &r1;
            else if ((c == 1) || (c == 6))
               pieces[r][c] = &n1;
            else if ((c == 2) || (c == 5))
               pieces[r][c] = &b1;
            else if (c == 3)
               pieces[r][c] = &q1;
            else if (c == 4)
               pieces[r][c] = &k1;
         }
         else if (r == 1) // set black pawns
            pieces[r][c] = &p1;
         else if (r == 6) // set white pawns
            pieces[r][c] = &p2;
         else if (r == 7) // set white pieces
         {
            if ((c == 0) || (c == 7))
               pieces[r][c] = &r2;
            else if ((c == 1) || (c == 6))
               pieces[r][c] = &n2;
            else if ((c == 2) || (c == 5))
               pieces[r][c] = &b2;
            else if (c == 3)
               pieces[r][c] = &q2;
            else if (c == 4)
               pieces[r][c] = &k2;
         }
         else
            pieces[r][c] = &s; //set spaces
      }
}

/**************************************
 * MOVE PIECE: move a piece
 **************************************/
void Board::movePiece()
{
    // set coordinates to proper array position
      int sr = 56 - (int)cmd[1]; // source array row and column
      int sc = (int)cmd[0] - 97; 
      int dr = 56 - (int)cmd[3]; // destination array row and column
      int dc = (int)cmd[2] - 97; 

      // move the piece and clear old square
      pieces[dr][dc] = pieces[sr][sc];
      pieces[sr][sc] = &s;
}

/**************************************
 * BOARD: DISPLAY
 * displays a header and then board
 **************************************/
void Board::display()
{
   if (!test)
   {
    // display header
      system("clear");
   cout << "  ";
   for (char i = 'a'; i <= 'h'; i++)
      cout << " "
           << i
           << " ";
   cout << endl;
   // display board
   for (int r = 0; r < 8; r++)
   {
      cout << 8 - r
           << " ";
      for (int c = 0, pos = 0; c <= 7; c++, pos++)
      {
         if (!isWhiteSquare[r][c])
            if (pieces[r][c]->getID() <= 'R')
               cout << "\E[30;41m" << " " << pieces[r][pos]->getName()
                     << " " << "\E[0m"; // black square, black piece or blank
            else
               cout << "\E[37;41m" << " " << pieces[r][pos]->getName()
                    << " " << "\E[0m"; // black square, white piece
         else
            if (pieces[r][c]->getID() <= 'R')
               cout << "\E[30;47m" << " " << pieces[r][pos]->getName()
                    << " " << "\E[0m"; // white square, black piece or blank
            else
               cout << "\E[31;47m" << " " << pieces[r][pos]->getName()
                    << " " << "\E[0m"; // white square, white piece
               
               
      }
      cout << endl;
   }
   }
   else
   {
      cout << "  ";
    for (char i = 'a'; i <= 'h'; i++)
       cout << i;
   cout << endl;
   // display board
   for (int r = 0; r < 8; r++)
   {
      cout << 8 - r
           << " ";
      for (int c = 0, pos = 0; c <= 7; c++, pos++)
      {
         cout << pieces[r][pos]->getID();               
      }
      cout << endl;
   }
}
}
