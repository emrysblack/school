/***********************************************************************
* Program:
*    Project 3, Chess with Objects 
*    Brother Boyer, CS165
* Author:
*    Brady Field
* Summary:
*    A program to play an object-oriented version of the chess game.
*    Uses two header files for the board and the pieces. This is just 
*    the driver program for the game.
*
*    Estimated:  20.0 hrs   
*    Actual:     0.0 hrs
*      Hardest part?
************************************************************************/
#include <iostream>
#include <string>
#include "piece.h"
#include "board.h"
using namespace std;

void getMove(Board &board);
bool isMenu(Board &board);
void displayMenu();
void quit();

/***************************************************
 * MAIN: displays board and starts game loop
 ***************************************************/
int main()
{
   Board board;
   board.display();

   // commandLoop
   while (!board.done)
   {
      getMove(board);
   }
   return 0;
}

/***************************************************
 * GET MOVE: prompts user for move
 ***************************************************/
void getMove(Board &board)
{
   cout << board.getPlayer() << ": ";
   cin >> board.cmd;
   isMenu(board);
      
}

/***************************************************
 * IS MENU: determines if menu command
 ***************************************************/
bool isMenu(Board &board)
{
   if (board.cmd == "?")
      displayMenu();
   else if (board.cmd == "read")
      cout << "read file\n";
   else if (board.cmd == "help")
      cout << "display possible moves\n";
   else if (board.cmd == "test")
   {
      board.test = true;
      board.display();
   }
   else if (board.cmd == "quit")
   {
      board.done = true;
      quit();
   }
   else
      if (!board.validMove())
         return false;
      else
      {
         board.movePiece();
         board.changePlayer();
         board.display();
      }
      
      

   return true;
}

/****************************************************
 * DISPLAY MENU: displays possbile options
 ****************************************************/
void displayMenu()
{
   cout << "Options:\n"
           << "?      Display these options\n"
           << "b2b4   Specify a move using the Smith Notation\n"
           << "read   Read a saved game from a file\n"
           << "help   Display all possible moves for a given piece\n"
           << "test   Simple display for test purposes\n"
           << "quit   Leave the game. You will be prompted to save\n";
}

/****************************************************
 * QUIT: prompts for save and exits program
 ****************************************************/
void quit()
{
   cout << "To save a game, please specify the filename.\n"
        << "    To quit without saving a file, just press <enter>\n";
}
