/***********************************************************************
 * Program:
 *    Project 2, Pong
 *    Brother Helfrich, CS165
 * Author:
 *    Br. Helfrich
 * Summary:
 *    OK, I couldn't help myself.  The first video game is "Tennis for Two"
 *    developed in 1958 (you read that correctly) by William Higinbotham
 *    as a demo for the computer systems in the Brookhaven National Laboratory.
 *    The display was a normal oscilloscope.  Ours will use slighly more
 *    advanced graphics: OpenGL
 ***********************************************************************/

#include "ui.h"

#define PADDLE 20

/*****************************************
 * PONG
 * The main pong structure containing everything
 * necessary to plan our beloved game
 ****************************************/
struct Pong
{
   Point ball;   // ball position
   int dx;       // ball horizontal velocity
   int dy;       // vertical velocity
   bool dead;    // is the game over?
   int score;
   int score1;
   Point paddle; // location of the paddle
   int pAngle;
};

class Bullet
{
public:
   Bullet();
   ~Bullet();
   Point dot;
   bool isDead;
   int dx;
   int dy;
};
Bullet dot[5];

/*******************************************
 * default constructor
 *******************************************/
Bullet :: Bullet()
{
   dot.x = 127;
   dot.y = -127;
   isDead = true;
   dx = 0;
   dy = 0;
}

/*******************************************
 * deconstructor
 *******************************************/
Bullet :: ~Bullet()
{
}

/*******************************************
 * fires a bullet
 *******************************************/
void fireBullet(Bullet *b, int pAngle)
{
   b->dx = 5;
   b->dy = 2;
   b->isDead = false;
}

/*******************************************
 * BOUNCE
 * Bounce the walls off the 3 sides
 ******************************************/
void bounce(Pong *pPong)
{
   // woops, we missed the ball!
   if ((pPong->ball.x > 128) || (pPong->ball.y > 128) || (pPong->ball.y < -128))
   {
      pPong->dead = true;
      pPong->ball.x = 0;
      pPong->ball.y = 200; // off screen
      pPong->dx = 0;
      pPong->dy = 0;
      pPong->score1++;

      // regenerate the bird
       pPong->ball.x = -126;
       pPong->ball.y = random(-126, 126, "Initial position of bird");
       pPong->dx = 4;
       if (pPong->ball.y < 0)
          pPong->dy = random(0, 4, "Initial vertical velocity of ball");
       else
          pPong->dy = random(-4, 0, "Initial vertical velocity of ball");
       pPong->dead = false;
   }

}

/*******************************************
 * Bullet miss
 ******************************************/
void bulletMiss(Bullet *pPong)
{
   // woops, we missed the ball!
   if ((pPong->dot.x > 128) || (pPong->dot.y > 128) || (pPong->dot.y < -128)
       || (pPong->dot.x < -128))
   {
      pPong->isDead = true;
      pPong->dot.x = 0;
      pPong->dot.y = 200; // off screen
      pPong->dx = 0;
      pPong->dy = 0;

      // regenerate the bullets
       pPong->dot.x = 127;
       pPong->dot.y = -127;
       pPong->dx = 0;
       pPong->dy = 0;
   }

}

/****************************************
 * STRIKE
 * Strike the paddle.  The further from the center,
 * the more it hits
 ****************************************/
void strike(Pong *pPong)
{
   // ball not at the paddle yet
   if (pPong->ball.x < 125)
      return;

   // missed!
   int distance = (int)(pPong->ball.y - pPong->paddle.y);
   if (abs(distance) > PADDLE)
      return;
   
   // yeah, we hit the ball

   // hit.  Change the dx direction.
   // pPong->dx *= -1;

   // get some score
   pPong->score++;

   // speed up every 5 points
   // if (pPong->score % 5 == 0)
   //   pPong->dx--;

   // the dy is changed by the angle.
   pPong->dy += distance / 5;
}

/*********************************************
 * CALLBACK
 * The main interaction loop of the engine.
 *********************************************/
void callBack(const Graphics *pGraphics, void *p)
{
   
   
   bool empty = false;
   Bullet *b;
   Pong *pPong = (Pong *)p;
   const Point SCORE = {-120, 120};
   const Point SCORE1 = {100, 120};

   // ready the bullet to be fired
   if (dot[0].isDead)
      b = &dot[0];
   else if (dot[1].isDead)
      b = &dot[1];
   else if (dot[2].isDead)
      b = &dot[2];
   else if (dot[3].isDead)
      b = &dot[3];
   else if (dot[4].isDead)
      b = &dot[4];
   else
      empty = true;
   
   // advance the ball and bullets
   bounce(pPong);
   pPong->ball.x += pPong->dx;
   pPong->ball.y += pPong->dy;
  

   // check the gun angle
   if ((pGraphics->isUpPress) || (pGraphics->isRightPress))
      pPong->pAngle -= 2;
   if ((pGraphics->isDownPress) || (pGraphics->isLeftPress))
      pPong->pAngle += 2;
   strike(pPong);

   // fire bullets
   if (pGraphics->isSpacePress)
      fireBullet(b, pPong->pAngle);
   
   // advance bullets
   
    for(int i = 0; i < 5; i++)
      if(!dot[i].isDead)      
      {
         dot[i].dot.x -= dot[i].dx;
         dot[i].dot.y += dot[i].dy;
      }
   
   // draw the gun
   drawRect(pPong->paddle, 5, 40, pPong->pAngle);

   // draw the ball
   if (!pPong->dead)
      drawCircle(pPong->ball, 10, 20, 0);

   // draw the bullets and advance them
   for (int i = 0; i < 5; i++)
      if (!dot[i].isDead)
      {
         drawDot(dot[i].dot);
         bulletMiss(&dot[i]);
      }

   // draw the score
   drawNumber(SCORE, pPong->score);
   drawNumber(SCORE1, pPong->score1);
}

/*********************************
 * Just initialize
 * my ball type and call the display engine.
 * That is all!
 *********************************/
int main(int argc, char **argv)
{
   Pong pong;   
   pong.ball.x = -126;
   pong.ball.y = random(-126, 126, "Initial position of bird");
   pong.dx = 4;
   pong.dy = random(-4, 4, "Initial vertical velocity of bird");
   pong.dead = false;
   pong.score = 0;
   pong.score1 = 0;
   pong.paddle.x = 127;
   pong.paddle.y = -127;
   pong.pAngle = 45;
   
   initialize(argc, argv, string("Skeet Shoot"),
              callBack, &pong);
   run();
}
