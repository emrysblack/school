/********************
 *
 ***************/
#include <iostream>
using namespace std;

class Test
{
public:
   Test();
   friend ostream& operator <<(ostream& out, Test& rhs);
private:
   int text;
};

/*************
 *
 ************/
   Test:: Test()
{
   text = 10;
}

/**************
 *
 *************/
ostream& operator <<(ostream& out, Test& rhs)
{
   out << rhs.text;
   return out;
}

/************
 *
 ***************/
int main()
{
   Test test1;
   cout << test1 << endl;
   return 0;
}
