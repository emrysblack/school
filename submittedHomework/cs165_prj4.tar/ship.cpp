/****************************************
 * UI TEST
 * Just a simple program to test the user
 * interface consisting of uiDraw and uiInteract
 ***************************************/


#include "point.h"
#include "uiInteract.h"
#include "uiDraw.h"
using namespace std;

/************************************
 * Test structure to capture the ball
 * that I will move around the screen
 ***********************************/
class Ship
{
public:
   Ship() : speed(0), rotation(0), dx(0), dy(0) { };
   void fireBullet (Point *pt);
   Point pt;
   int rotation;
   float dx;
   float dy;
   float speed;
};

class Bullet
{
   Bullet() : speed(0), rotation(0), dx(0), dy(0) { };
   Point pt;
   int rotation;
   float dx;
   float dy;
   float speed;
};

/***********************
 * degrees to radians
 ***********************/
float deg2rad(float value)
{
   return (M_PI / 180) * value;
}
/*****************************************
 * shoots a bullet
 *****************************************/
void Ship::fireBullet(Point *pt)
{   
}

/*************************************
 * All the interesting work happens here, when
 * I get called back from OpenGL to draw a frame.
 * When I am finished drawing, then the graphics
 * engine will wait until the proper amount of
 * time has passed and put the drawing on the screen.
 **************************************/
void callBack(const Interface *pUI, void *p)
{

   Ship *pShip = (Ship *)p;
   
   if (pUI->isRight())
      pShip->rotation -= 10;
   if (pUI->isLeft())
      pShip->rotation += 10;
   if (pUI->isUp())
      pShip->speed += 0.2;
   if (pUI->isDown())
      if (pShip->speed > 0)
         pShip->speed -= 0.2;
      else
         pShip->speed = 0;
   
   pShip->dx = pShip->speed * sin(deg2rad(pShip->rotation));
   pShip->dy = pShip->speed * cos(deg2rad(pShip->rotation));
   // use the space bar to fire bullets
   if (pUI->isSpace())
      pShip->fireBullet(&pShip->pt);
   //if (pBall->sides == 12)
   //   pBall->sides = 3;
   // move ship
   //pShip->point.y -= pShip->dy;
   pShip->pt.addY (pShip->dy);
   //pShip->point.x += pShip->dx;
   pShip->pt.addX (-pShip->dx);

   // draw
   drawShip(pShip->pt, /*position*/
              pShip->rotation - 90 /*rotation*/);
}



/*********************************
 * Main is pretty sparse.  Just initialize
 * my ball type and call the display engine.
 * That is all!
 *********************************/
int main(int argc, char **argv)
{
   Interface ui(argc, argv, "Asteroids");
   Ship ball;
   ui.run(callBack, &ball);

   return 0;
}
