# pokebattle
To compile, just run make.
To use the program, it just needs 2 clients running the a.out
use the m option on both for multi-player.
it will display the host number and port number to give to the other client.
After both clients have connected, it will automatically start the game